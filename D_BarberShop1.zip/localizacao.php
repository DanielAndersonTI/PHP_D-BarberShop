
<?php include 'header.php'; ?>

<section class="localizacao-container">
    <h2>Localização</h2>
    <p>Clique no botão abaixo para abrir a localização da barbearia.</p>
    <a href="https://maps.app.goo.gl/bibJWM5rLyBX9Fvc9" target="_blank" class="botao">Partiu Barbearia! 🚗💨</a>
</section>

<?php include 'footer.php'; ?>