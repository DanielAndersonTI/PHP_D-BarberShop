<?php
return [
    'servername' => 'sql312.infinityfree.com', 
    'username' => 'se0_38540346', 
    'password' => 'DanielASS2025', 
    'dbname' => 'if0_38540346_d_barbearia' 
];
?>
