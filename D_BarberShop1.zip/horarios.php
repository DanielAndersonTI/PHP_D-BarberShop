
<?php include 'header.php'; ?>

<section class="horarios-container">
    <h2>Horários de Funcionamento</h2>
    <ul>
        <li><strong>Terça a Sábado:</strong> 9:30 às 12:00 / 14:00 às 19:00</li>
        <li><strong>Domingo:</strong> 9:30 às 12:00</li>
        <li><strong>Feriados:</strong> 9:30 às 12:00</li>
        <li><strong>Segunda:</strong> Fechado</li>
        <li><strong>Almoço:</strong> 12:00 às 14:00</li>
    </ul>
    <a href="index.php" class="botao-voltar">Voltar</a>
</section>

<?php include 'footer.php'; ?>