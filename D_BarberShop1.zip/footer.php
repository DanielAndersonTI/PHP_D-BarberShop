<footer>
    <p>&copy; 2025 D' Barber Shop - Todos os direitos reservados.</p>
</footer>